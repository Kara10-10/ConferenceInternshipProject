package com.internshipProject.Conference.services;

import com.internshipProject.Conference.models.Report;
import org.springframework.stereotype.Service;

import  java.util.ArrayList;
import  java.util.List;

@Service
public class ReportService {
    private List<Report> reports = new ArrayList<>();
    private  long ID = 0;

    {
        reports.add(new Report(++ID, "Matfiz", "lecture", 301, 15));
        reports.add(new Report(++ID, "OOP", "lecture", 325, 16));
    }

    public List<Report> listReports() {return reports;}

    public void saveReport(Report report)
    {
        report.setId(++ID);
        reports.add(report);
    }

    public void deleteReport(Long id)
    {
        reports.removeIf(report -> report.getId().equals(id));
    }

    public Report getReportById(Long id){
        for(Report report: reports) {
            if(report.getId().equals(id)) return report;
        };
        return  null;
    }
}
