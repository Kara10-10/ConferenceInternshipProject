package com.internshipProject.Conference.controllers;

import com.internshipProject.Conference.models.Report;
import com.internshipProject.Conference.services.ReportService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ReportController {
    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping("/report/{id}")
    public  String reportInfo(@PathVariable Long id, Model model){
        model.addAttribute("report", reportService.getReportById(id));
        return "report-info";
    }
    @GetMapping("/")
    public  String reports(Model model){
        model.addAttribute("reports", reportService.listReports());
        return "reports";
    }

    @PostMapping("/report/create")
    public String createReport(Report report){
        reportService.saveReport(report);
        return "redirect:/";
    }

    @PostMapping("/report/delete/{id}")
    public String deleteReport(@PathVariable Long id){
        reportService.deleteReport(id);
        return "redirect:/";
    }
}
